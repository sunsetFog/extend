export const LINKEDIN_FULLNAME = '111';
export const GITHUB_USERNAME = '@2222';

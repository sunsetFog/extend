import React from 'react';
import styles from './index.modules.scss';

function NotFound() {
    return <div className={styles['not-found-root']}>404</div>;
}

export default NotFound;

export interface demmo {
    offset?: number;
    limit: number;
}

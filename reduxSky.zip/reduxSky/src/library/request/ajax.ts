import { setup } from 'sunny-js/request/ajax';
import ajaxSetup from './ajaxSetup';
export { default } from 'sunny-js/request/ajax';
export * from 'sunny-js/request/ajax';
setup(ajaxSetup);

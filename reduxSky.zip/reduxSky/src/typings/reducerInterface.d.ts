declare interface Action {
  type: string
  payload?: any
}

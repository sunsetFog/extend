const nameSpace = 'APP';

export const CHANGE_THEME_NAME = `${nameSpace}/CHANGE_THEME_NAME`; // 切换主题
export const UPDATE_MESSAGE_COUNT = `${nameSpace}/UPDATE_MESSAGE_COUNT`; // 更新未读消息数
export const UPDATE_BULLETIN_COUNT = `${nameSpace}/UPDATE_BULLETIN_COUNT`; // 更新未读公告
export const UPDATE_CONTACTS = `${nameSpace}/UPDATE_CONTACTS`; // 更新在线客服
export const IS_SHOW = `${nameSpace}/IS_SHOW`; // 全局加载
export const UPDATE_SETPAYPASSWORDINFO = `${nameSpace}/UPDATE_SETPAYPASSWORDINFO`; // 是否绑定密码

module.exports = { extends: ['@commitlint/config-conventional'] };
// type must be one of [build, chore, ci, docs, feat, fix, perf, refactor, revert, style, test] [type-enum]
//git commit -m "chore: lint on commitmsg"
